ONLORE SEASON 1 — ENGLISH EDITION

MP4: English narration, English on-screen text, burned-in English subtitles.
Video format: vertical 1080x1920, 24 fps, H.264 video / AAC audio.
Synthetic narration; original synthesized ambient music and illustrative graphics.

The opening follows the supplied hook: What is ONLORE Season 1 building?
The planned prize pool is not represented as a guaranteed payout.
Disclosure: Created for the ONLORE Season 1 campaign.

Upload the reviewed video to YouTube or TikTok, then submit its public link
under Make a video > Short video (under 5 min) on ONLORE.
Rewards remain subject to the campaign rules and review.
